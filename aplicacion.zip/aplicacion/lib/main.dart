import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aplicación IoT',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: LoginScreen(),
    );
  }
}

class BaseScreen extends StatelessWidget {
  final String usuario;
  final Widget body;

  BaseScreen({required this.usuario, required this.body});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Bienvenido, $usuario'),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text(
                'Menú',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              title: Text('Dashboard (Noticias)'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => DashboardScreen(usuario: usuario)),
                );
              },
            ),
            ListTile(
              title: Text('Acerca de'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => AcercaDeScreen(usuario: usuario)),
                );
              },
            ),
            ListTile(
              title: Text('Consultas'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => ConsultaScreen(usuario: usuario)),
                );
              },
            ),
            ListTile(
              title: Text('Tu Perfil'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => TuPerfilScreen(usuario: usuario)),
                );
              },
            ),
          ],
        ),
      ),
      body: body,
    );
  }
}

class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Inicio de Sesión'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              decoration: InputDecoration(
                labelText: 'Usuario',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            TextField(
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'Contraseña',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                primary: Colors.blue,
                onPrimary: Colors.white,
              ),
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => BienvenidaScreen(usuario: 'UsuarioEjemplo')),
                );
              },
              child: Text('Iniciar Sesión'),
            ),
          ],
        ),
      ),
    );
  }
}

class BienvenidaScreen extends StatelessWidget {
  final String usuario;

  BienvenidaScreen({required this.usuario});

  @override
  Widget build(BuildContext context) {
    return BaseScreen(
      usuario: usuario,
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              '¡Bienvenido, $usuario!',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => SeleccionPantallasScreen(usuario: usuario)),
                );
              },
              child: Text('Continuar'),
            ),
          ],
        ),
      ),
    );
  }
}

class SeleccionPantallasScreen extends StatelessWidget {
  final String usuario;

  SeleccionPantallasScreen({required this.usuario});

  @override
  Widget build(BuildContext context) {
    return BaseScreen(
      usuario: usuario,
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => DashboardScreen(usuario: usuario)),
                );
              },
              child: Text('Dashboard (Noticias)'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => AcercaDeScreen(usuario: usuario)),
                );
              },
              child: Text('Acerca de'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => ConsultaScreen(usuario: usuario)),
                );
              },
              child: Text('Consultas'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => TuPerfilScreen(usuario: usuario)),
                );
              },
              child: Text('Tu Perfil'),
            ),
          ],
        ),
      ),
    );
  }
}

class DashboardScreen extends StatelessWidget {
  final String usuario;
  final List<String> noticias = [
    'Noticia 1: Desnivel detectado en la zona A',
    'Noticia 2: Nuevo récord de temperatura registrado',
    'Noticia 3: Alerta de desviación crítica',
    'Noticia 4: Se detectaron picos altos',
  ];

  DashboardScreen({required this.usuario});

  @override
  Widget build(BuildContext context) {
    return BaseScreen(
      usuario: usuario,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Bienvenido al Dashboard, $usuario',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 20),
          Column(
            children: noticias
                .map(
                  (noticia) => Card(
                    child: ListTile(
                      title: Text(noticia),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ElevatedButton(
                            onPressed: () {
                              _mostrarDialogo(context, 'Revisar', noticia);
                            },
                            child: Text('Revisar'),
                          ),
                          SizedBox(width: 8),
                          ElevatedButton(
                            onPressed: () {
                              _mostrarDialogo(context, 'Ignorar', noticia);
                            },
                            child: Text('Ignorar'),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
                .toList(),
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context); // Retrocede a la pantalla de selección de pantallas
            },
            child: Text('Volver a Seleccionar Pantallas'),
          ),
        ],
      ),
    );
  }

  _mostrarDialogo(BuildContext context, String accion, String noticia) {
    String textoAccion = '';

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Responder a la Noticia'),
          content: Column(
            children: [
              Text(noticia),
              TextField(
                onChanged: (value) {
                  textoAccion = value;
                },
                decoration: InputDecoration(
                  labelText: 'Texto para la acción "$accion"',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
          actions: [
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context); // Cerrar el diálogo
              },
              child: Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () {
                _mostrarMensajeEnviado(context, textoAccion);
                Navigator.pop(context); // Cerrar el diálogo
              },
              child: Text('Enviar'),
            ),
          ],
        );
      },
    );
  }

  _mostrarMensajeEnviado(BuildContext context, String textoAccion) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Mensaje Enviado'),
          content: Text('La acción "$textoAccion" ha sido enviada exitosamente.'),
          actions: [
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context); // Cerrar el diálogo
                Navigator.pop(context); // Retrocede a la pantalla de noticias
              },
              child: Text('Aceptar'),
            ),
          ],
        );
      },
    );
  }
}

class AcercaDeScreen extends StatelessWidget {
  final String usuario;

  AcercaDeScreen({required this.usuario});

  @override
  Widget build(BuildContext context) {
    return BaseScreen(
      usuario: usuario,
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Bienvenido a la sección de Acerca De, $usuario',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context); // Retrocede a la pantalla de selección de pantallas
              },
              child: Text('Volver a Seleccionar Pantallas'),
            ),
          ],
        ),
      ),
    );
  }
}

class ConsultaScreen extends StatelessWidget {
  final String usuario;
  final List<String> opcionesConsulta = [
    'Consulta 1: Información General',
    'Consulta 2: Últimos Registros',
    'Consulta 3: Estadísticas',
  ];

  ConsultaScreen({required this.usuario});

  @override
  Widget build(BuildContext context) {
    return BaseScreen(
      usuario: usuario,
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Seleccione una Opción de Consulta',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Column(
              children: opcionesConsulta
                  .map(
                    (opcion) => Card(
                      child: ListTile(
                        title: Text(opcion),
                        onTap: () {
                          _mostrarDialogoConsulta(context, opcion);
                        },
                      ),
                    ),
                  )
                  .toList(),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context); // Retrocede a la pantalla de selección de pantallas
              },
              child: Text('Volver a Seleccionar Pantallas'),
            ),
          ],
        ),
      ),
    );
  }

  _mostrarDialogoConsulta(BuildContext context, String opcion) {
    String textoConsulta = '';

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Realizar Consulta: $opcion'),
          content: Column(
            children: [
              TextField(
                onChanged: (value) {
                  textoConsulta = value;
                },
                decoration: InputDecoration(
                  labelText: 'Texto para la Consulta',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
          actions: [
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context); // Cerrar el diálogo
              },
              child: Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () {
                print('Texto de consulta: $textoConsulta');
                Navigator.pop(context); // Cerrar el diálogo
              },
              child: Text('Enviar'),
            ),
          ],
        );
      },
    );
  }
}

class TuPerfilScreen extends StatelessWidget {
  final String usuario;

  TuPerfilScreen({required this.usuario});

  @override
  Widget build(BuildContext context) {
    return BaseScreen(
      usuario: usuario,
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Bienvenido a Tu Perfil, $usuario',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context); // Retrocede a la pantalla de selección de pantallas
              },
              child: Text('Volver a Seleccionar Pantallas'),
            ),
          ],
        ),
      ),
    );
  }
}
